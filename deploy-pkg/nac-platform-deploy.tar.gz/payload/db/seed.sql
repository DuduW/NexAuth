-- 全新环境最小种子数据（v1.6）：不含任何源环境数据
-- 仅含：后台初始账号(admin) + admin 组 + 基础业务组 group-guest + 本机测试 NAS
-- 安装完成后请立即在后台修改 admin 密码
SET NAMES utf8mb4;

INSERT INTO radcheck (username, attribute, op, value) VALUES ('admin', 'Cleartext-Password', ':=', 'admin123');
INSERT INTO radusergroup (username, groupname, priority) VALUES ('admin', 'admin', 10);
INSERT INTO radgroupreply (groupname, attribute, op, value) VALUES ('admin', 'Reply-Message', ':=', 'Admin Access');
INSERT INTO radgroupreply (groupname, attribute, op, value) VALUES ('group-guest', 'Reply-Message', ':=', 'Guest Access');
INSERT INTO nas (nasname, shortname, type, ports, secret, server, community, description)
VALUES ('127.0.0.1', 'localhost', 'other', 1812, 'testing123', '', '', '本机测试客户端');
